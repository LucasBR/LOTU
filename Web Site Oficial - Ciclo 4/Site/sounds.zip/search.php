<?
	header("Location: ./index.htm?page=_search_message.htm");
?>
