<?
	// ----- Traitement newsletter ----- //
	
	
	// --------------------------------- //
	
	header("Location: ./index.htm?page=_newsletter_message.htm");
?>
